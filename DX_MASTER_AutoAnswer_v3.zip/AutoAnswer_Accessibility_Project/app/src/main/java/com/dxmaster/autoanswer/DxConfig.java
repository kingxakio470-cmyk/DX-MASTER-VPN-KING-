package com.dxmaster.autoanswer;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * DX MASTER — shared settings (used by the app screen and the service).
 */
public final class DxConfig {

    private DxConfig() {}

    public static final String PREFS = "dx_master_prefs";

    public static final String K_ENABLED   = "enabled";        // master switch
    public static final String K_DELAY     = "delay_sec";      // 0..10
    public static final String K_ALL_APPS  = "all_apps";       // listen in every app
    public static final String K_VIDEO     = "answer_video";   // also answer video calls
    public static final String K_JOIN      = "join_group";     // auto "Join" for group / multi calls
    public static final String K_TOTAL     = "total_answered";
    public static final String K_LAST_TIME = "last_time";
    public static final String K_LAST_APP  = "last_app";
    public static final String K_GROUP     = "group_";         // + group id

    /** An app (or a family of apps) the user can switch on/off. */
    public static final class Group {
        public final String id;
        public final String label;
        public final String[] packages;

        Group(String id, String label, String... packages) {
            this.id = id;
            this.label = label;
            this.packages = packages;
        }
    }

    public static final Group[] GROUPS = {
            new Group("phone", "ফোন কল (সাধারণ কল)",
                    "com.android.incallui", "com.google.android.dialer",
                    "com.samsung.android.incallui", "com.android.dialer",
                    "com.android.phone", "com.android.server.telecom"),
            new Group("messenger", "Messenger",
                    "com.facebook.orca", "com.facebook.mlite"),
            new Group("facebook", "Facebook",
                    "com.facebook.katana", "com.facebook.lite"),
            new Group("whatsapp", "WhatsApp",
                    "com.whatsapp", "com.whatsapp.w4b"),
            new Group("telegram", "Telegram",
                    "org.telegram.messenger", "org.telegram.messenger.web"),
            new Group("imo", "IMO",
                    "com.imo.android.imoim"),
            new Group("instagram", "Instagram",
                    "com.instagram.android"),
            new Group("viber", "Viber",
                    "com.viber.voip"),
            new Group("meet", "Google Meet / Duo",
                    "com.google.android.apps.tachyon"),
            new Group("clone", "ডুয়াল / ক্লোন অ্যাপ",
                    "com.lbe.parallel.intl", "com.excelliance.dualaid",
                    "com.ludashi.dualspace", "com.polestar.super.clone")
    };

    /** Apps where a plain "Join" button is NOT a call (groups, pages, events, browsers...). */
    private static final String[] JOIN_BLOCKED = {
            "com.facebook.katana", "com.facebook.lite", "com.instagram.android",
            "com.android.chrome", "com.google.android.youtube", "org.mozilla.firefox",
            "com.android.settings", "com.google.android.gm"
    };

    public static boolean isJoinAllowed(String pkg) {
        if (pkg == null) return false;
        for (String s : JOIN_BLOCKED) {
            if (s.equals(pkg)) return false;
        }
        return true;
    }

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Is this package allowed to trigger an auto answer? */
    public static boolean isPackageAllowed(SharedPreferences p, String pkg) {
        if (pkg == null) return false;
        if (p.getBoolean(K_ALL_APPS, true)) return true;
        // heads-up call notifications are drawn by System UI
        if (pkg.equals("com.android.systemui")) return true;
        for (Group g : GROUPS) {
            if (!p.getBoolean(K_GROUP + g.id, true)) continue;
            for (String s : g.packages) {
                if (s.equals(pkg)) return true;
            }
        }
        return false;
    }
}
